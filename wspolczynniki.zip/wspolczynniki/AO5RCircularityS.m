function Rc1 = AO5RCircularityS( im )
Rc1 = 2*sqrt(sum(sum(im))/pi);
end

